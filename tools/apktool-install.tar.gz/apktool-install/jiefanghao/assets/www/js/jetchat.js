(function (global) {
	var emptyFn=function(){};
	global.jetchat=global.jetchat||{};
	/*
	*开始座谈会
	*symposiumJid:房間的jid
	*isOwner:是否為會議發起人
	*例如：jetchat.startSymposium('xxxxxxx',true);
	*/
	global.jetchat.startSymposium=function(symposiumJid,isOwner){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "startSymposium", [symposiumJid,isOwner]);
	}
	
	/*
	*打开某个聊天房间
	*例如：jetchat.chat(json);
	* json {roomJid:"点对点或多人聊天的房间jid", userId:"nvbu@sanguo.com", roomTitle:"房间标题(可选)"}
	*/
	global.jetchat.chat=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "chat", [json]);
	}
		
	/*
	*报名参加座谈会
	{
	 symposiumJid：座谈会的jid,
	 title：标题,
	 description：描述,
	 startTime: 开始时间,
	 endTime: 结束时间,
	 ownerJid: 发起人的jid
	}
	*/
	global.jetchat.applySymposium=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "applySymposium", [json]);
	}


	/*
	*查看简历
	{personId：用户id}
	*例如：jetchat.viewResume({personId:425});
	*/
	global.jetchat.viewResume=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "viewResume", [json]);
	}

	/*
	*打开一个页面
	*{title:'标题',url:'地址'}
	*例如：jetchat.open({title:'google',url:'http://g.cn'});
	*/
	global.jetchat.open=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "open", [json]);
	}

	/*
	*选择联系人
	*参数：{callback:'回调函数名称',selectedContacts:[初始选择人员的userid数组(联系人不可删除)]}
	*例如：jetchat.chooseContacts({callback:'myFunction',selectedContacts:['liubei@sanguo.com','caocao@sanguo.com']});
	*将会从打开手机的联系人选择界面(默认选中selectedContacts参数指定的‘刘备’和‘曹操’)，选择好联系人后调用页面的方法：myFunction([选择用户的userid数组])
	*/
	global.jetchat.chooseContacts=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "chooseContacts", [json]);
	}
	
	/*
	*关闭当前页面，并进入到jetchat的登陆页
	*参数：{ userName:'caocao@sanguo.com', //自动填入的用户名[可选]
	*        password:'diaochan', //自动填入的密码[可选]
	*        doLogin:true //如果为true表示执行登陆[可选]
	*      }
	*例如：jetchat.toLoginPage({userName:'caocao@sanguo.com'});
	*/
	global.jetchat.toLoginPage=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "toLoginPage", [json]);
	}
	
	/*
	*当设备就绪后执行
	*参数：要执行的函数
	*例如：jetchat.ready(function(){alert('I am ready')});
	*/
	global.jetchat.ready=function(fun){
		global.jetchat.readyFun=fun;
	}
	
	/*
	*使用native控件显示信息
	*参数：要显示的信息
	*例如：jetchat.show('操作成功');
	*/
	global.jetchat.show=function(msg){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "show", [msg]);
	}
	
	/*
	*查看用户详情
	*参数：{userId：用户账号}
	*例如：jetchat.showUserDetail({userId:'zhaoyun@sanguo.com'});
	*/
	global.jetchat.showUserDetail=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "showUserDetail", [json]);
	}


	/*
	*转发
	*参数：{title:'消息的标题',content:'描述',source:'消息的来源',url:'点击消息的跳转地址', image:'此消息的图片'}
	*例如：jetchat.forward({title:'【官方活动】众包推荐悬赏——你找人，我推荐，用人脉赚奖金！',content:'为加速组织社会资源参与注册ITS企业用户项目的提交，鼓励JointForce注册用户推荐有能力的人才加入JointForce参与众包/兼职任务的提交，JointForce平台将对推荐者进行奖励',source:'jointFocre',url:'http://bbs.jointforce.cn/forum.php?mod=viewthread&tid=13004', image:'http://bbs.jointforce.com/uc_server/data/avatar/000/00/21/44_avatar_small.jpg'})
	*/
	global.jetchat.forward=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "forward", [json]);
	}	
	
	/*
	*打开通讯录 原轻应用中的chooseContacts
	*{callback:'回调函数名称',selectedContacts:[初始选择人员的userid数组(联系人可删除)]}
	*callback:必须，回调函数名称，例如：‘dosomexing’
	*selected:可选，已选择的userid，例如：['zhangfei@sanguo.com','lvbu@sanguo.com']
	*singleChoose:是否单选 false 表示多选 true表示单选
	*limit:最大数限制
	*例如：{callback:'回调函数名称',selectedContacts:[初始选择人员的userid数组],singleChoose:true,limit:10}
	*/
	global.jetchat.modifyContacts=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "modifyContacts", [json]);
	}
	
	/*
	* 拨打电话
	* 例如：{phoneNumber:'13813801380'}
	* phoneNumber：电话号码，例如:'13813801380'
	*/
	global.jetchat.callPhone=function(json) {
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "callPhone", [json]);
	}
	
	/*
	* 通知客户端刷新我的账号信息
	*/
	global.jetchat.refreshAccount=function(){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "refreshAccount", []);
	}
	
	/*
	* 关闭当前activity
	*/
	global.jetchat.close=function(){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "close", []);
	}
	
	/*
	* 通知app此需求的详情已看过（app用于清除对应的通知，android特有，调用的时候先请判断是否存在此函数：typeof jetchat.entryRequirementDetail == 'function'）
	* 在需求详情页面调用，例如：jetchat.entryRequirementDetail({orderId:425})
	*/
	global.jetchat.entryRequirementDetail=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "entryRequirementDetail", [json]);
	}
	
	/*
	 * 分享到微信/微信朋友圈
	 *{url:'url的绝对地址',title:'标题',description:'描述',icon:'图片的绝对url地址',toTimeline:true|false}
	 *toTimeline为true表示分析到朋友圈
	 * 例如：jetchat.share2weixin({url:'http://www.jointforce.com/jfperiodical/news/show/109?m=d03',
	 * title:'日活跃用户过亿？',description:'日活跃用户过亿？5000万屈指可数，1000万已算成功',icon:'https://www.jointforce.com/logo.png',toTimeline:true});
	 */
	global.jetchat.share2weixin=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "share2weixin", [json]);
	}
	
	/*
	* 打开native页面或者web页面
	* 例如：jetchat.go("jetchat://invite",function(processed){ alert(processed)});
	*/
	global.jetchat.go=function(url,callback){
		cordova.exec(function(processed){
			if(typeof callback == 'function'){
				callback(processed);
			}
		}, function (error) {alert(error)}, "Jetchat", "go", [url]);
	}
	
	/*
	* 执行action
	* 例如：jetchat.action("jfaction://linkmate.invite?target=13811836882",function(processed){ alert(processed)});
	*/
	global.jetchat.action=function(url,callback){
		cordova.exec(function(processed){
			if(typeof callback == 'function'){
				callback(processed);
			}
		}, function (error) {alert(error)}, "Jetchat", "action", [url]);
	}
	
	/*
	 * 获取设备信息，例如：
	 *  jetchat.ready(function(){
	 *  	jetchat.getDevice(function(device){
	 *			alert(device.IMEI);//设备码
	 *			alert(device.isWXAppInstalled);//是否安装了微信
	 *		})
	 *	})
	 */
	global.jetchat.getDevice=function(callback){
		if(global.jetchat.device){
			if(typeof callback == 'function'){
				callback(global.jetchat.device);
			}
		}else{
			cordova.exec(function(device){
				global.jetchat.device=device;
				if(typeof callback == 'function'){
					callback(global.jetchat.device);
				}
			}, function (error) {alert(error)}, "Jetchat", "getDevice", []);
		}
	}
	
	/*
	* 通知App检查是否绑定手机号
	* jetchat.bindMobile(function(success){if(success) alert('bind success!')});
	*/
	global.jetchat.bindMobile=function(callback){
		cordova.exec(function(success){
			if(typeof callback == 'function'){
				callback(success);
			}
		}, function (error) {alert(error)}, "Jetchat", "bindMobile", []);
	}

	/*
    * 使用jftoken进行登录
    * jetchat.doLogin(
      {
      jfrandom:'3009765538409723124',
      jftime:1433731407326,
      jfuserid:'hanpeng@chinasofti.com',
      jftoken:'647A2EA9CB426CF2D0A2A24F1398A079'
      }
      )
    */
	global.jetchat.doLogin=function(json){
    	cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "doLogin", [json]);
    }

	/*
	* 关闭web页面时是否弹出确认对话框
	* jetchat.bindCloseConfirm("确认关闭吗（回退请按back键）？");
	*/
	global.jetchat.bindCloseConfirm=function(confirmTip){
		if(global.jetchat.isReady){
			cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "bindCloseConfirm", [confirmTip]);
		}else{
			document.addEventListener("deviceready",function() {
				cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "bindCloseConfirm", [confirmTip]);
			}, false);
		}
	}
	
	/*
	* 控制webview的loadingMask
	* 例如隐藏遮罩：jetchat.showMask(false);
	*/
	global.jetchat.showMask=function(show){
		if(global.jetchat.isReady){
			cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "showMask", [show]);
		}else{
			document.addEventListener("deviceready",function() {
				cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "showMask", [show]);
			}, false);
		}
		
	}

    /*
    * 分享到第三方平台（为了兼容多个平台而增加了这个api，用此api可以分享到qq，qq空间，微信等，原来的share2weixin仍可以使用）
    * platform:qq,qzone为qq空间,wx微信,wx_timeline微信朋友圈
    * 例如：jetchat.share({url:'详情地址',titile:'标题',description:'描述',icon:'图片地址',platform:'qq或qzone或wx或wx_timeline'});
    */
	global.jetchat.share=function(json){
        cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "share", [json]);
    }

    /*
    * 设置页面菜单（目前只能通过level设置，将来可以细分自定义）
    * level为private: 表示页面是私有的，只有刷新按钮，例如个人信息页
    * level为normal: 默认页面，表示只要登录了解放号就能打开，有刷新，复制链接，转发等（因为需要登录，所有没有分享到微信等按钮）
    * level为public: 公开的页面，不需要登录也能打开，也可以再外部浏览器打开，有全部的功能按钮，包括分享到微信，qq等
    * 例如：jetchat.setPageMenu({level:'public'});
    */
    global.jetchat.setPageMenu=function(json){
        cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "setPageMenu", [json]);
    }

    /*
    * web页的友盟事件统计
    *{key:"JF_UM_1101",value:{k1:v1,k2:v2}}
    * 例如：jetchat.share({key:'JF_UM_100', attribute:{key1:'value1',key2:'value2'}});
    */
    global.jetchat.umeng=function(json){
        cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "umeng", [json]);
    }

    /*
    * 后台关闭前一个页面，使当前页面返回时，直接返回到上上个页面
    */
    global.jetchat.closePrevious=function(){
        cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "closePrevious", []);
    }

    /*
    * 打开web页面的操作页面
    */
    global.jetchat.openShare=function(){
            cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "openShare", []);
    }

    /*
    * web页面发送聊天消息
    *jetchat.sendmsg(userId:'liujin@chinasofti.com',msg:'12345')
    *jetchat.sendmsg(userId:'qiyun@chinasofti.com',"msg":"<jf-cmd action=\"linkMessage\" title=\"微信开发\"
    *url=\"aHR0cHM6Ly9kZXYuam9pbnRmb3JjZS5jb20vbWFwcC8jL3NlcnZpY2UvTWpneE96SXo=\"
    *image=\"aHR0cHM6Ly9zdmNpbWcuam9pbnRmb3JjZS5jb20vamZzZXJ2aWNlcy9maWxlL2Rldi8yODEvcGljLzFfNTlmNDc3NGYtZjI2OC00MTY5LWI3ZTgtMWVhOTM5ODUxMWEwX3N1LmpwZw==\"
    *content=\"¥ 3000\" toFront=\"true\"\/>",
    */
    global.jetchat.sendmsg=function(json){
        cordova.exec(emptyFn, function (error) {alert(error)}, "Jetchat", "sendmsg", [json]);
    }

	document.addEventListener("deviceready",function() {
		global.jetchat.isReady=true;
		if(typeof global.jetchat.readyFun == "function"){
			global.jetchat.readyFun();
		}
	}, false);
	
	global.jetChat=global.jetchat;//fuck this
})(this);
