(function (global) {
	var emptyFn=function(){};
	global.jetchat=global.jetchat||{};
	global.jetchat.app=global.jetchat.app||{};
	/*
	*打开通讯录
	*{callback:'回调函数名称',selectedContacts:[初始选择人员的userid数组]}
	*callback:必须，回调函数名称，例如：‘dosomexing’
	*selected:可选，已选择的userid，例如：['zhangfei@sanguo.com','lvbu@sanguo.com']
	*singleChoose:是否单选 false 表示多选 true表示单选
	*例如：{callback:'回调函数名称',selectedContacts:[初始选择人员的userid数组],singleChoose:true}
	*/
	global.jetchat.app.chooseContacts=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "JsLightApp", "chooseContacts", [json]);
	}
	
	/*
	* 拨打电话
	* 例如：{phoneNumber:'13813801380'}
	* phoneNumber：电话号码，例如:'13813801380'
	*/
	global.jetchat.app.callPhone=function(json) {
		cordova.exec(emptyFn, function (error) {alert(error)}, "JsLightApp", "callPhone", [json]);
	}
	
	/*
	* 发送聊天
	* 例如：{userId:'lvbu@sanguo.com'}
	*/
	global.jetchat.app.chat=function(json){
		cordova.exec(emptyFn, function (error) {alert(error)}, "JsLightApp", "chat", [json]);
	}
	
	global.jetchat.App=global.jetchat.app;//fuck this
})(this);
